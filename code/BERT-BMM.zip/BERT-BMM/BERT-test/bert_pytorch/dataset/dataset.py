from torch.utils.data import Dataset
import tqdm
import torch
import random
import numpy as np
import pickle
import os
import re
from collections import defaultdict
import sparse as sp #version 0.1.0


import sparse as sp #version 0.1.0

special_ch=['all_token','null','*','[','(',')',':','-',']','_',',','+']

def m_to_sparse(m):
    return sp.COO(m)

def list_to_str(token_list):
    result = ''
    for t in token_list:
        result += t+' '
    return result

def get_sub_token_for_list(token_list):
    result=[]
    for token_s in token_list:
        result = result+get_sub_token(token_s)
    return result

def get_sub_token(token_s):
    t=''
    sub_token_list=[]
    for ch in token_s:
        if ch not in special_ch:
            t = t+ch
        else:
            if len(t)>0:
                sub_token_list.append(t)
            sub_token_list.append(ch)
            t=''
    if len(t)>0:
        sub_token_list.append(t)
    return sub_token_list

class BERTDataset(Dataset):
    def __init__(self, dataset_type, corpus_path, vocab, seq_len, encoding="utf-8", corpus_lines=None, on_memory=True):
        self.vocab = vocab
        self.seq_len = seq_len

        self.on_memory = on_memory
        self.corpus_lines = corpus_lines
        self.corpus_path = corpus_path
        self.encoding = encoding

        self.valid = True
        self.sample_path = ""
        self.bb_amount = 0
        self.dfg_node_amount = 0
        self.prog_inst_dic = defaultdict(str)
        self.dt = None

        self.dataset_type = dataset_type

        self.lines = []
        self.get_lines(corpus_path)

        
    def get_inst_tokens(self,inst_line):
        ts=inst_line.split()
        try:
            inst_addr = int(ts[0].rstrip(':'),16)
        except ValueError:
            print('[WARNING] ValueError')
        del ts[0]  
        ts = list_to_str(get_sub_token_for_list(ts))
        self.prog_inst_dic[inst_addr] = ts
        return ts #type:str

    def get_lines(self,data_path):

        if self.dataset_type == "poj":
            #get_lines for poj dataset
            #其实不需要读这么多文件，只需要xx_arg,xx_bb,xx_dfg_arg
            bb_f = open(data_path+"_bb")
            adj_f = open(data_path+"_adj",'rb')
            arg_f = open(data_path+"_arg")
            dfg_adj_f = open(data_path+"_dfg_adj",'rb')
            dfg_arg_f = open(data_path+"_dfg_arg")
            cg_adj_f = open(data_path+"_cg_adj",'rb')
            cg_arg_f = open(data_path+"_cg_arg")        
            if (os.path.getsize(data_path+"_bb")==0) or \
            (os.path.getsize(data_path+"_adj")==0) or \
            (os.path.getsize(data_path+"_arg")==0) or \
            (os.path.getsize(data_path+"_dfg_adj")==0) or \
            (os.path.getsize(data_path+"_dfg_arg")==0) or \
            (os.path.getsize(data_path+"_cg_adj")==0) or \
            (os.path.getsize(data_path+"_cg_arg")==0):
                self.valid = False
                return None
            
            # add bb tokens to self.lines
            prog_bb_amount = 0
            arg_line = arg_f.readline()
            while arg_line: #every func
                func_addr,bb_amount = map(int,arg_line.split())
                arg_line = arg_f.readline()
                bb_ins_amount_list = list(map(int,arg_line.split()))
                for i in range(bb_amount): #every bb
                    prog_bb_amount += 1
                    bb_addr = -1
                    tokens = '' #BB的全部tokens
                    for j in range(bb_ins_amount_list[i]): #bb中每条指令
                        bb_line = bb_f.readline()
                        tmp_s=bb_line.split()
                        try:
                            inst_addr = int(tmp_s[0].rstrip(':'),16) #把前面的addr取出，tokens去除前面的“addr:” (格式为addr: tokens 如（0x400578: sub rsp, 8）)
                        except ValueError:
                            continue
                        if j==0:
                            bb_addr = inst_addr
                        del tmp_s[0] #去除“addr:”  
                        tmp_s = list_to_str(get_sub_token_for_list(tmp_s)) #把tokens重新组织为需要的格式
                        self.prog_inst_dic[inst_addr] = tmp_s #存储在字典中，之后解析dfg时，拿到addr就可以得到对应指令的token序列
                        tokens += tmp_s #token序列加上这条指令的tokens
                    line = ['all_token',tokens,1]
                    #只生成dfg instruction eb时，暂时不需要bb的tokens，只需要dfg的tokens，要注释下面一句：self.lines.append(line)
                    self.lines.append(line)
                arg_line = arg_f.readline()
                arg_line = arg_f.readline()
            

            # add dfg tokens to self.lines
            dfg_node_amount = int(dfg_arg_f.readline())
            for i in range(dfg_node_amount):
                node_addr = re.findall(r'<(.+?) id=',dfg_arg_f.readline())
                if len(node_addr)>0:
                    node_addr = int(node_addr[0],16) #得到这个节点的addr
                    tokens = self.prog_inst_dic[node_addr] #从上面生成的字典（prog_inst_dic）中得到这个节点的token序列
                    if tokens == '':
                        tokens = 'null'
                    line = ['all_token',tokens,1]
                    self.lines.append(line)
                else:
                    tokens = 'null'
                    line = ['all_token',tokens,1]
                    self.lines.append(line)
            
            self.bb_amount = prog_bb_amount
            self.dfg_node_amount = dfg_node_amount
            self.corpus_lines = len(self.lines)

        elif self.dataset_type == 'spec_new': #TODO：spec_new未完成与spe_dfg_build.py的对齐，需要修改一致，spec_dfg_build.py将数据按照字典组织，仅需要修改关键词即可
            print('[DEBUG] load data from:',data_path)
            data_file = open(data_path,'rb')
            dt = pickle.load(data_file) #{'func_list':func_list, 'DFGAS':AS,'dfg_node_list':dfg_node_list, 'CGAS':CGAS, 'cg_node_list':cg_node_list}
            self.dt = dt
            print('DATA SET SIZE:',len(dt['func_list']))
            func_list = dt['func_list']
            prog_bb_amount = 0
            for func in func_list:
                addr = func['addr']
                block_cnt = func['block_cnt']
                cfg = func['cfg']
                bb_list = func['bb_list'] #every bb in list:{'bb_addr':block.instruction_addrs[0],'bb':inst_list}
                for bb in bb_list:
                    prog_bb_amount += 1
                    tokens = ''
                    for inst in bb['bb']:
                        tokens += self.get_inst_tokens(inst)
                    #line = ['all_token',tokens,1]
                    #self.lines.append(line)
            
            dfg_line_amount = 0
            dfg_node_list = dt['dfg_node_list']
            print('[DEBUG] dfg size:',len(dfg_node_list))
            for node_addr in dfg_node_list:
                dfg_line_amount += 1
                if node_addr>=0:
                    tokens = self.prog_inst_dic[node_addr]
                    if tokens == '':
                        tokens = 'null'
                    line = ['all_token',tokens,1]
                    self.lines.append(line)
                else:
                    tokens = 'null'
                    line = ['all_token',tokens,1]
                    self.lines.append(line)

            self.bb_amount = 0 # no cfg node to create eb
            self.dfg_node_amount = dfg_line_amount
            self.corpus_lines = len(self.lines)
            print('Load data finish. lenth =',self.corpus_lines)
        
        elif self.dataset_type == 'spec_old': #spec的老版本无dfg数据
            data_path0, bench = data_path.split('@')[0],data_path.split('@')[1]
            #get_lines for spec dataset
            bb_f = open(data_path0+"_result/bb_"+bench)
            # adj_f = open(data_path0+"_result/adj_"+bench)
            arg_f = open(data_path0+"_result/label_"+bench)
            # cg_adj_f = open(data_path0+"_cg/adj_"+bench)
            # cg_arg_f = open(data_path0+"_cg/node_"+bench)        
            
            # add bb tokens to self.lines
            prog_bb_amount = 0
            arg_line = arg_f.readline()
            while arg_line: #every func
                func_addr,bb_amount,cfg_label = map(int,arg_line.split())
                arg_line = arg_f.readline()
                bb_ins_amount_list = list(map(int,arg_line.split()))
                # datamat=np.empty([bb_cnt,bb_cnt])
                for i in range(bb_amount):
                    prog_bb_amount += 1
                    bb_addr = -1
                    tokens = '' #BB的token序列
                    # adj_line = adj_f.readline()
                    # line=adj_line.strip().split()
                    # datamat[i,:]=line[:]
                    for j in range(bb_ins_amount_list[i]):
                        bb_line = bb_f.readline()
                        tmp_s=bb_line.split()
                        try:
                            inst_addr = int(tmp_s[0].rstrip(':'),16)
                        except ValueError:
                            continue
                        if j==0:
                            bb_addr = inst_addr
                        del tmp_s[0]  
                        tmp_s = list_to_str(get_sub_token_for_list(tmp_s))
                        tokens += tmp_s #加上这条指令的tokens
                    if len(tokens)==0:
                        print('[Error] tokens lenth==0')
                    line = ['all_token',tokens,1]
                    self.lines.append(line)
                arg_line = arg_f.readline()
                arg_line = arg_f.readline()
            
            self.bb_amount = prog_bb_amount
            self.dfg_node_amount = 0 #暂时还没有spec的dfg输入，只有cfg，cg
            self.corpus_lines = len(self.lines)
            print('Load data finish. lenth =',self.corpus_lines)
        else:
            print('[DEBUG] wrong dataset_type:',self.dataset_type)

    def update_eb(self,eb_list):
        print('Start update eb for dt')
        dt = self.dt
        eb_index = 0
        # for func in dt['func_list']:
        #     bb_list = func['bb_list'] #every bb in list:{'bb_addr':block.instruction_addrs[0],'bb':inst_list}
        #     for bb in bb_list:
        #         bb['bb'] = eb_list[eb_index]
        #         eb_index += 1
        #     func['bb_list'] = bb_list
        
        dfg_node_list = dt['dfg_node_list']
        for dfg_node_index in range(len(dfg_node_list)):
            dfg_node_list[dfg_node_index] = eb_list[eb_index]
            eb_index += 1
        dt['dfg_node_list'] = dfg_node_list
            
        return dt



    def __len__(self):
        return self.corpus_lines

    def __getitem__(self, item):
        #t1, t2, is_next_label = self.random_sent(item)
        t1, t2, is_next_label = self.get_labeled_data(item)
        is_next_label = int(is_next_label)
        t1_random, t1_label = self.random_word(t1)
        t2_random, t2_label = self.random_word(t2)

        # [CLS] tag = SOS tag, [SEP] tag = EOS tag
        t1 = [self.vocab.sos_index] + t1_random + [self.vocab.eos_index]
        t2 = t2_random + [self.vocab.eos_index]

        t1_label = [self.vocab.pad_index] + t1_label + [self.vocab.pad_index]
        t2_label = t2_label + [self.vocab.pad_index]

        segment_label = ([1 for _ in range(len(t1))] + [2 for _ in range(len(t2))])[:self.seq_len]
        bert_input = (t1 + t2)[:self.seq_len]
        bert_label = (t1_label + t2_label)[:self.seq_len]

        padding = [self.vocab.pad_index for _ in range(self.seq_len - len(bert_input))]
        bert_input.extend(padding), bert_label.extend(padding), segment_label.extend(padding)

        output = {"bert_input": bert_input, #sentence t1+t2
                  "bert_label": bert_label,
                  "segment_label": segment_label,
                  "is_next": is_next_label}

        return {key: torch.tensor(value) for key, value in output.items()}

    def random_word(self, sentence):
        tokens = sentence.split()
        output_label = []

        for i, token in enumerate(tokens):
            prob = random.random()
            if prob < 0.15:
                prob /= 0.15

                # 80% randomly change token to mask token
                if prob < 0.8:
                    tokens[i] = self.vocab.mask_index

                # 10% randomly change token to random token
                elif prob < 0.9:
                    tokens[i] = random.randrange(len(self.vocab))

                # 10% randomly change token to current token
                else:
                    tokens[i] = self.vocab.stoi.get(token, self.vocab.unk_index)

                output_label.append(self.vocab.stoi.get(token, self.vocab.unk_index))

            else:
                tokens[i] = self.vocab.stoi.get(token, self.vocab.unk_index)
                output_label.append(0)

        return tokens, output_label

    def random_sent(self, index):
        t1, t2 = self.get_corpus_line(index)

        # output_text, label(isNotNext:0, isNext:1)
        if random.random() > 0.5:
            return t1, t2, 1
        else:
            return t1, self.get_random_line(), 0

    def get_corpus_line(self, item):
        if self.on_memory:
            return self.lines[item][0], self.lines[item][1]
        else:
            line = self.file.__next__()
            if line is None:
                self.file.close()
                self.file = open(self.corpus_path, "r", encoding=self.encoding)
                line = self.file.__next__()

            t1, t2 = line[:-1].split("\t")
            return t1, t2

    def get_random_line(self):
        if self.on_memory:
            return self.lines[random.randrange(len(self.lines))][1]

        line = self.file.__next__()
        if line is None:
            self.file.close()
            self.file = open(self.corpus_path, "r", encoding=self.encoding)
            for _ in range(random.randint(self.corpus_lines if self.corpus_lines < 1000 else 1000)):
                self.random_file.__next__()
            line = self.random_file.__next__()
        return line[:-1].split("\t")[1]

    def get_labeled_data(self, item):
        if self.on_memory:
            return self.lines[item][0], self.lines[item][1], self.lines[item][2]
        else:
            line = self.file.__next__()
            if line is None:
                self.file.close()
                self.file = open(self.corpus_path, "r", encoding=self.encoding)
                line = self.file.__next__()

            t1, t2, label = line[:-1].split("\t")
            return t1, t2, label

    def save_new_sample(self, f, eb_list):
        prog_func_max = 32
        func_bb_max = 32
        bb_eb_dim = len(eb_list[0])
        CFG = np.zeros(((prog_func_max,func_bb_max,func_bb_max)))
        CFG_nodes = np.zeros((((prog_func_max,func_bb_max,bb_eb_dim))))
        func_i = 0
        eb_index = 0
        for func in self.dt['func_list']:
            adjm = func.cfg_A.todense()
            adjm = np.pad(adjm,((0,func_bb_max-len(func.bb_list)),(0,func_bb_max-len(func.bb_list))),'constant',constant_values = (0,0))
            CFG[func_i] = adjm
            bb_i = 0
            for bb in func.bb_list:
                CFG_nodes[func_i,bb_i] = eb_list[eb_index]
                eb_index += 1
                bb_i += 1
            func_i += 1
        CFG_As = sp.COO(CFG)
        CFG_nodes = sp.COO(CFG_nodes)
        sample_t = {'CFG_As':CFG_As,\
                'CFG_nodes':CFG_nodes,\
                'label_compile':self.dt['label_compile'],\
                'label_class':self.dt['label_class'],\
                'label_fileid':self.dt['label_fileid']}
        pickle.dump(sample_t, f, pickle.HIGHEST_PROTOCOL)



    



