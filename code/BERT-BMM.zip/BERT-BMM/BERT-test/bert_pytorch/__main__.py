import argparse

import torch
from torch.utils.data import DataLoader
import glob

from .model import BERT
from .trainer import BERTTrainer
from .dataset import BERTDataset, WordVocab

import sparse as sp #version 0.1.0
import os
import re
import pickle

def train():
    parser = argparse.ArgumentParser()

    parser.add_argument("-c", "--train_dataset", required=False, type=str, help="train dataset for train bert")
    parser.add_argument("-t", "--test_dataset", type=str, default=None, help="test set for evaluate train set")
    parser.add_argument("-v", "--vocab_path", required=True, type=str, help="built vocab model path with bert-vocab")
    parser.add_argument("-o", "--output_path", required=False, type=str, help="ex)output/bert.model")

    parser.add_argument("-hs", "--hidden", type=int, default=256, help="hidden size of transformer model")
    parser.add_argument("-l", "--layers", type=int, default=8, help="number of layers")
    parser.add_argument("-a", "--attn_heads", type=int, default=8, help="number of attention heads")
    parser.add_argument("-s", "--seq_len", type=int, default=20, help="maximum sequence len")

    parser.add_argument("-b", "--batch_size", type=int, default=64, help="number of batch_size")
    parser.add_argument("-e", "--epochs", type=int, default=10, help="number of epochs")
    parser.add_argument("-w", "--num_workers", type=int, default=5, help="dataloader worker size")

    parser.add_argument("--with_cuda", type=bool, default=True, help="training with CUDA: true, or false")
    parser.add_argument("--log_freq", type=int, default=10, help="printing loss every n iter: setting n")
    parser.add_argument("--corpus_lines", type=int, default=None, help="total number of lines in corpus")
    parser.add_argument("--cuda_devices", type=int, nargs='+', default=None, help="CUDA device ids")
    parser.add_argument("--on_memory", type=bool, default=True, help="Loading on memory: true or false")

    parser.add_argument("--lr", type=float, default=1e-3, help="learning rate of adam")
    parser.add_argument("--adam_weight_decay", type=float, default=0.01, help="weight_decay of adam")
    parser.add_argument("--adam_beta1", type=float, default=0.9, help="adam first beta value")
    parser.add_argument("--adam_beta2", type=float, default=0.999, help="adam first beta value")

    parser.add_argument("--load_model_path", type=str, default="", help="path of model to load")
    parser.add_argument("--ori_sample_input_path", type=str, default="ori_sample/", help="path of ori sample")
    parser.add_argument("--train_sample_save_path", type=str, default="ready_sample/", help="path of ready sample")
    parser.add_argument("--compiler_id", type=int, default="0", help="compiler id(0-9)")
    parser.add_argument("--class_id_start", type=int, default="0", help="class_id_start")
    parser.add_argument("--dataset_type", type=str, default="null", help="which dataset to use （spe_old/poj）")
    parser.add_argument("--debug", type=bool, default=False, help="is debug")

    args = parser.parse_args()

    print("Run bert on gpu:",args.cuda_devices)
    print("Task: compiler id ",str(args.compiler_id)," start class id ", args.class_id_start)

    print("Loading Vocab", args.vocab_path)
    vocab = WordVocab.load_vocab(args.vocab_path)
    print("Vocab Size: ", len(vocab))

    # print("Loading Train Dataset", args.train_dataset)
    # train_dataset = BERTDataset(args.train_dataset, vocab, seq_len=args.seq_len,
    #                             corpus_lines=args.corpus_lines, on_memory=args.on_memory)

    print("Building BERT model")
    bert = BERT(len(vocab), hidden=args.hidden, n_layers=args.layers, attn_heads=args.attn_heads)

    print("Load BERT model from", args.load_model_path)
    if args.load_model_path != "":
        bert = torch.load(args.load_model_path)


    # f_dir = args.ori_sample_input_path
    # data_list=glob.glob(f_dir+"*.pkl")
    # sample_index = 0
    # for sample_path in data_list:
    #     sample_name = sample_path.split('/')[1]

    dataset_type=args.dataset_type

    if dataset_type == "poj":
        compiler_list=['gcc','llvm']
        opti_tag_list_llvm=['O2','O3']
        opti_tag_list_gcc=['O0','O1','O2','O3','O0_ffast','O1_ffast','O2_ffast','O3_ffast']

        
        #compiler, opti_tag = get_compiler_type(args.compiler_id,dataset_type)
        for compiler_id_i in [0,1,4,5]: #目标编译配置 0:llvmO2，1:llvmO3，4:gccO2，5:gccO3
            compiler, opti_tag = get_compiler_type(compiler_id_i,dataset_type)

            poj_path='../poj_bench/'
            in_path0=poj_path+'poj_data/'+compiler+'/'+opti_tag+'/'
            class_id_range=104 #遍历所有程序类别
            if args.debug:
                class_id_range=1 + args.class_id_start
                print('Debug: class_id_range',class_id_range)
            for class_id in range(args.class_id_start, class_id_range): #遍历所有程序类别
                in_path=in_path0+str(class_id+1)+'/'
                file_list = get_file_in_poj_class(in_path) #获取这个类别下的所有程序编号(程序名)
                for file_index, file_id in enumerate(file_list):
                    file_path = in_path+str(file_id) #路径
                    print("Loading Test Dataset", file_path)
                    #test_dataset = BERTDataset(dataset_type, file_path, vocab, seq_len=args.seq_len, on_memory=args.on_memory) \
                    #    if args.ori_sample_input_path is not None else None
                    test_dataset = BERTDataset(dataset_type, file_path, vocab, seq_len=args.seq_len, on_memory=args.on_memory) #初始化数据集

                    if test_dataset.valid == False:
                        continue

                    #print("Creating Dataloader")
                    #train_data_loader = DataLoader(train_dataset, batch_size=args.batch_size, num_workers=args.num_workers)
                    test_data_loader = DataLoader(test_dataset, batch_size=args.batch_size, num_workers=args.num_workers) \ 
                        if test_dataset is not None else None #初始化数据加载器

                    #print("Creating BERT Trainer")
                    trainer = BERTTrainer(bert, len(vocab), train_dataloader=None, test_dataloader=test_data_loader,
                                        lr=args.lr, betas=(args.adam_beta1, args.adam_beta2), weight_decay=args.adam_weight_decay,
                                        with_cuda=args.with_cuda, cuda_devices=args.cuda_devices, log_freq=args.log_freq)
                        
                    

                    eb_list = trainer.create_eb() #获得所有语料的eb，返回到eb_list

                    #存储到两个文件，新cfg_node，新dfg_node
                    f_name_bb_bert = file_path+"_bb_bert"+str(args.hidden) #cfg
                    f_name_dfg_arg_bert = file_path+"_dfg_bb_bert"+str(args.hidden) #dfg
                    f_eb_bb = open(f_name_bb_bert, 'wb')
                    f_eb_dfg = open(f_name_dfg_arg_bert, 'wb')
                    print("Saving Bert Dataset", f_name_bb_bert, f_name_dfg_arg_bert)

                    #同时输出bb的eb和dfg instruction的eb时
                    bb_bert_matrix = m_to_sparse(eb_list[0:test_dataset.bb_amount])
                    pickle.dump(bb_bert_matrix, f_eb_bb, pickle.HIGHEST_PROTOCOL)
                    dfg_arg_bert_matrix = m_to_sparse(eb_list[test_dataset.bb_amount:test_dataset.corpus_lines])
                    pickle.dump(dfg_arg_bert_matrix, f_eb_dfg, pickle.HIGHEST_PROTOCOL)


                    # # #只输出dfg instauction的eb时（与上面注释二选一）
                    # f_name_dfg_arg_bert = file_path+"dfg_arg_bert_ginn"+str(args.hidden)
                    # f_eb_dfg = open(f_name_dfg_arg_bert, 'wb')
                    # print("Saving Bert Dataset", f_name_dfg_arg_bert)
                    # dfg_arg_bert_matrix = m_to_sparse(eb_list)
                    # pickle.dump(dfg_arg_bert_matrix, f_eb_dfg, pickle.HIGHEST_PROTOCOL)
                    
                    if args.debug and file_index>=3:
                        break
    elif dataset_type == 'spec_old':
        compiler_list=['gcc','llvm']
        opti_tag_list=['O2','O3']
        data_file_list=["505.mcf_r","508.namd_r","510.parest_r","520.omnetpp_r","523.xalancbmk_r","544.nab_r","557.xz_r","526.blender_r","502.gcc_r","511.povray_r","538.imagick_r","541.leela_r"]
        
        #compiler, opti_tag = get_compiler_type(args.compiler_id,dataset_type)
        for compiler_id_i in [0,1,4,5]: #目标编译配置 0:llvmO2，1:llvmO3，4:gccO2，5:gccO3
            compiler, opti_tag = get_compiler_type(compiler_id_i,dataset_type)

            spec_path='/data_hdd/myself/guanxin/gpu02/angr/'
            in_path0=spec_path+compiler+'_'+opti_tag+'_test_data/'+compiler+'_'+opti_tag+'_test'
            class_id_range = 12 #12个spec benchmark
            if args.debug:
                class_id_range=1 + args.class_id_start
                print('Debug: class_id_range',class_id_range)
            for class_id in range(args.class_id_start, class_id_range): 
                file_path=in_path0+'@'+data_file_list[class_id]

                print("Loading Test Dataset", file_path)
                # test_dataset = BERTDataset(dataset_type, file_path, vocab, seq_len=args.seq_len, on_memory=args.on_memory) \
                #     if args.ori_sample_input_path is not None else None 
                test_dataset = BERTDataset(dataset_type, file_path, vocab, seq_len=args.seq_len, on_memory=args.on_memory)  #初始化数据集

                if test_dataset.valid == False:
                    continue

                #print("Creating Dataloader")
                #train_data_loader = DataLoader(train_dataset, batch_size=args.batch_size, num_workers=args.num_workers)
                test_data_loader = DataLoader(test_dataset, batch_size=args.batch_size, num_workers=args.num_workers) \
                    if test_dataset is not None else None #数据加载器

                #print("Creating BERT Trainer")
                trainer = BERTTrainer(bert, len(vocab), train_dataloader=None, test_dataloader=test_data_loader,
                                    lr=args.lr, betas=(args.adam_beta1, args.adam_beta2), weight_decay=args.adam_weight_decay,
                                    with_cuda=args.with_cuda, cuda_devices=args.cuda_devices, log_freq=args.log_freq)

                eb_list = trainer.create_eb() #获得所有语料的eb，存储到eb_list

                f_name_bb_bert = in_path0+"_result/"+"bb_bert_"+data_file_list[class_id] #eb输出文件
                f_eb_bb = open(f_name_bb_bert, 'wb')
                bb_bert_matrix = m_to_sparse(eb_list[0:test_dataset.bb_amount])
                pickle.dump(bb_bert_matrix, f_eb_bb, pickle.HIGHEST_PROTOCOL)
                print("Saving Bert Dataset", f_name_bb_bert)
                
    elif dataset_type == 'spec_new': #无效，本意是按照spec_dfg_build.py生成的新的数据格式来读取和处理，但是因为中途几次修改格式，数据也多次变动，此处的修改未与最新版本的spef_dfg_build.py格式对齐，但可以按照spec_dfg_build.py来进行修改（格式修改要在dataset.py中进行）
        compiler_list=['gcc','llvm']
        opti_tag_list=['O2','O3']
        #data_file_list=["505.mcf_r","508.namd_r","510.parest_r","520.omnetpp_r","523.xalancbmk_r","544.nab_r","557.xz_r","526.blender_r","502.gcc_r","511.povray_r","538.imagick_r","541.leela_r"]
        data_file_list=["520.omnetpp_r"]
        spec_path='/data_hdd/myself/guanxin/gpu02/graph_build_code/spec_data_dfg/'  #angr生成的文件路径
        

        #compiler, opti_tag = get_compiler_type(args.compiler_id,dataset_type)
        for compiler_id_i in [0,1,4,5]: #0,1,4,5
            compiler, opti_tag = get_compiler_type(compiler_id_i,dataset_type)
            
            #x86_llvm_O2_520.omnetpp_r_graph.pkl
            in_path0=spec_path+'x86_'+compiler+'_'+opti_tag+'_'
            class_id_range = 1
            if args.debug:
                class_id_range=1 + args.class_id_start
                print('[Debug] class_id_range',class_id_range)
            for class_id in range(args.class_id_start, class_id_range): 
                file_path=in_path0+data_file_list[class_id]+'_graph.pkl'

                print("Loading Test Dataset", file_path)
                # test_dataset = BERTDataset(dataset_type, file_path, vocab, seq_len=args.seq_len, on_memory=args.on_memory) \
                #     if args.ori_sample_input_path is not None else None
                test_dataset = BERTDataset(dataset_type, file_path, vocab, seq_len=args.seq_len, on_memory=args.on_memory)

                if test_dataset.valid == False:
                    continue

                #print("Creating Dataloader")
                #train_data_loader = DataLoader(train_dataset, batch_size=args.batch_size, num_workers=args.num_workers)
                test_data_loader = DataLoader(test_dataset, batch_size=args.batch_size, num_workers=args.num_workers) \
                    if test_dataset is not None else None

                #print("Creating BERT Trainer")
                trainer = BERTTrainer(bert, len(vocab), train_dataloader=None, test_dataloader=test_data_loader,
                                    lr=args.lr, betas=(args.adam_beta1, args.adam_beta2), weight_decay=args.adam_weight_decay,
                                    with_cuda=args.with_cuda, cuda_devices=args.cuda_devices, log_freq=args.log_freq)

                eb_list = trainer.create_eb() #获得所有语料的eb

                f_name = in_path0+data_file_list[class_id]+'_eb.pkl'
                f_eb_bb = open(f_name, 'wb')
                sample_eb_save = test_dataset.update_eb(eb_list)
                if sample_eb_save == None:
                    print('[ERROR] wrong eb_update, no data to save')
                else:
                    pickle.dump(sample_eb_save, f_eb_bb, pickle.HIGHEST_PROTOCOL)
                    print("Saving Bert Dataset", f_name)


def m_to_sparse(m):
    return sp.COO(m)

def get_file_in_poj_class(path):
    file_id_list=[]
    file_list = os.popen('ls '+path+'*_bb')
    #print(file_list)
    for line in file_list.readlines():
        file_list_new = re.findall(r'{}(.+?)_bb'.format(path),line)
        file_id_list.append(int(file_list_new[0]))
        #print(file_list_new[0])
    return file_id_list

def get_compiler_type(binary_type,dataset_type):
    if binary_type==0:
        compiler='llvm' 
        opti_tag='O2'
    if binary_type==1:
        compiler='llvm' 
        opti_tag='O3'  
    if binary_type==2:
        compiler='gcc' 
        opti_tag='O0'
    if binary_type==3:
        compiler='gcc' 
        opti_tag='O1'
    if binary_type==4:
        compiler='gcc' 
        opti_tag='O2'
    if binary_type==5:
        compiler='gcc' 
        opti_tag='O3'
    if binary_type==6:
        compiler='gcc'
        opti_tag='O0_ffast'
    if binary_type==7:
        compiler='gcc'
        opti_tag='O1_ffast'
    if binary_type==8:
        compiler='gcc'
        opti_tag='O2_ffast'
    if binary_type==9:
        compiler='gcc'
        opti_tag='O3_ffast'
    
    if dataset_type == "poj" or dataset_type == "spec_new":
        return compiler, opti_tag
    elif dataset_type == "spec_old":
        if opti_tag=='O2':
            opti_tag = 'o2'
        if opti_tag=='O3':
            opti_tag = 'o3'
        return compiler, opti_tag
    else:
        print("[DEBUG] wrong dataset_type:",dataset_type)

